# oceanwp-darkmode-plugin

Apply Dark Mode to OceanWP Theme
